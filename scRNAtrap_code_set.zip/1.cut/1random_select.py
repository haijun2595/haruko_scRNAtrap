import os
import random

def process_bacteria():
    def select_random_contigs_bacteria(input_files, output_file, contig_count):
        selected_contigs = set()
        file_iter = cycle_files(input_files)
        
        with open(output_file, 'w') as out_f:
            while len(selected_contigs) < contig_count:
                current_file = next(file_iter)
                with open(current_file, 'r') as in_f:
                    for line in in_f:
                        line = line.strip()
                        if not line or line.startswith('>') or 'N' in line or len(line) <= 50 or line in selected_contigs:
                            continue
                        
                        selected_contigs.add(line)
                        out_f.write(f"{line}\n")
                        
                        if len(selected_contigs) >= contig_count:
                            break
        
        if len(selected_contigs) != contig_count:
            raise ValueError("The number of selected contigs is incorrect.")
        print("Bacteria contigs file created successfully.")

    def cycle_files(files):
        while True:
            for file in files:
                yield file

    base_dir = 'Bacteria_Fasta_InputPath'
    output_file = 'Bacteria_5million_fasta_OutputPath/Bacteria.fasta'
    all_files = []
    for root, dirs, files in os.walk(base_dir):
        for file in files:
            if file.endswith('.fna'):
                all_files.append(os.path.join(root, file))
    select_random_contigs_bacteria(all_files, output_file, 5000000)

def process_virus():
    def select_random_contigs_virus(input_files, output_file, contig_count):
        selected_contigs = set()
        file_iter = cycle_files(input_files)
        
        with open(output_file, 'w') as out_f:
            while len(selected_contigs) < contig_count:
                current_file = next(file_iter)
                with open(current_file, 'r') as in_f:
                    for line in in_f:
                        line = line.strip()
                        if not line or line.startswith('>') or 'N' in line or len(line) <= 50 or line in selected_contigs:
                            continue
                        
                        selected_contigs.add(line)
                        out_f.write(f"{line}\n")
                        
                        if len(selected_contigs) >= contig_count:
                            break
        
        if len(selected_contigs) != contig_count:
            raise ValueError("The number of selected contigs is incorrect.")
        print("Virus contigs file created successfully.")

    def cycle_files(files):
        while True:
            for file in files:
                yield file

    input_dir = 'Virus_Fasta_InputPath'
    output_file = 'Virus_5million_fasta_OutputPath/Virus.fasta'
    all_files = [os.path.join(input_dir, f) for f in os.listdir(input_dir) if f.endswith('.fasta')]
    select_random_contigs_virus(all_files, output_file, 5000000)

def process_human():
    def select_random_contigs_human(input_file, output_file, contig_count):
        selected_contigs = set()
        
        with open(output_file, 'w') as out_f:
            with open(input_file, 'r') as in_f:
                while len(selected_contigs) < contig_count:
                    line = in_f.readline().strip()
                    if not line or line.startswith('>') or 'N' in line or len(line) <= 50 or line in selected_contigs:
                        continue
                    
                    selected_contigs.add(line)
                    out_f.write(f"{line}\n")
        
        if len(selected_contigs) != contig_count:
            raise ValueError("The number of selected contigs is incorrect.")
        print("Human contigs file created successfully.")

    input_file = 'Human_fna_InputPath'
    output_file = 'Human_5million_fasta_OutputPath/Human.fasta'
    select_random_contigs_human(input_file, output_file, 5000000)

if __name__ == "__main__":
    process_bacteria()
    process_virus()
    process_human()
    print("All contigs files created successfully.")