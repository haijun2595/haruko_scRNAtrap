import os
import random

def process_bacteria():
    def cut_and_write_bacteria(input_file, output_file):
        with open(output_file, 'w') as out_f:
            with open(input_file, 'r') as in_f:
                for line in in_f:
                    line = line.strip()
                    while True:
                        start_pos = random.randint(0, len(line) - 48)
                        if start_pos + 48 <= len(line):
                            cut_read = line[start_pos:start_pos + 48]
                            out_f.write(f"{cut_read}\n")
                            break
        print("Bacteria 48bp reads file created successfully.")

    input_file = 'Bacteria_5million_fasta_OutputPath/Bacteria.fasta'
    output_file = '5million_fasta_OutputPath_48bp/Bacteria.fasta'
    cut_and_write_bacteria(input_file, output_file)

def process_virus():
    def cut_and_write_virus(input_file, output_file):
        with open(output_file, 'w') as out_f:
            with open(input_file, 'r') as in_f:
                for line in in_f:
                    line = line.strip()
                    while True:
                        start_pos = random.randint(0, len(line) - 48)
                        if start_pos + 48 <= len(line):
                            cut_read = line[start_pos:start_pos + 48]
                            out_f.write(f"{cut_read}\n")
                            break
        print("Virus 48bp reads file created successfully.")

    input_file = 'Virus_5million_fasta_OutputPath/Virus.fasta'
    output_file = '5million_fasta_OutputPath_48bp/Virus.fasta'
    cut_and_write_virus(input_file, output_file)

def process_human():
    def cut_and_write_human(input_file, output_file):
        with open(output_file, 'w') as out_f:
            with open(input_file, 'r') as in_f:
                for line in in_f:
                    line = line.strip()
                    while True:
                        start_pos = random.randint(0, len(line) - 48)
                        if start_pos + 48 <= len(line):
                            cut_read = line[start_pos:start_pos + 48]
                            out_f.write(f"{cut_read}\n")
                            break
        print("Human 48bp reads file created successfully.")

    input_file = 'Human_5million_fasta_OutputPath/Human.fasta'
    output_file = '5million_fasta_OutputPath_48bp/Human.fasta'
    cut_and_write_human(input_file, output_file)

if __name__ == "__main__":
    process_bacteria()
    process_virus()
    process_human()
    print("All 48bp reads files created successfully.")