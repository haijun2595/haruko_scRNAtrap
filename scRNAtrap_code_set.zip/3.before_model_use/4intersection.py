import os

def read_fastq(file_path):
    reads = set()
    with open(file_path, 'r') as f:
        while True:
            header = f.readline().strip()
            if not header:
                break
            sequence = f.readline().strip()
            plus = f.readline().strip()
            quality = f.readline().strip()
            read_id = header.split()[0]
            reads.add(read_id)
    return reads

def read_full_fastq(file_path):
    reads = {}
    with open(file_path, 'r') as f:
        while True:
            header = f.readline().strip()
            if not header:
                break
            sequence = f.readline().strip()
            plus = f.readline().strip()
            quality = f.readline().strip()
            read_id = header.split()[0]
            reads[read_id] = (header, sequence, plus, quality)
    return reads

def write_fastq(output_file, reads):
    with open(output_file, 'w') as f:
        for read in reads.values():
            f.write('\n'.join(read) + '\n')

def main():
    dir_a = "Raw_fastq2_Path"
    dir_b = "Output_BAM_fastq_Path"
    output_dir = "Output_fastq2_intersection_Path"
    output_file = os.path.join(output_dir, "file_name.fastq")

    os.makedirs(output_dir, exist_ok=True)

    # Set B
    reads_b = {}
    for file_name in os.listdir(dir_b):
        if file_name.endswith(".fastq"):
            file_path = os.path.join(dir_b, file_name)
            reads_b.update(read_full_fastq(file_path))

    # Set A
    intersection_reads = {}
    for file_name in os.listdir(dir_a):
        if file_name.endswith("_2.fastq"):
            file_path = os.path.join(dir_a, file_name)
            reads_a = read_fastq(file_path)
            common_reads = reads_a.intersection(reads_b.keys())
            for read_id in common_reads:
                intersection_reads[read_id] = reads_b[read_id]

    # make intersection
    write_fastq(output_file, intersection_reads)

    print("The intersection file has been successfully generated.")

if __name__ == "__main__":
    main()