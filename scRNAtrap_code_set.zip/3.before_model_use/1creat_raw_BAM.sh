#!/bin/bash
##==== parameters ====

## File Paths
inPath="Input_Path"
outPath="Output_Path"

## STAR config
refIndex="Reference_Genome_Index_Path" #e.g. GRCh38-2020-A
CPU=16

## barcode config. Please choose this whitelist_10x for 10x 3'v2
whiteList="/singlecell_whitelist_Path/whitelist_10x 3'v2.txt"
barcode_setting="--soloCBstart 1 --soloCBlen 16 --soloUMIstart 17 --soloUMIlen 10 --soloBarcodeReadLength 0"

## barcode config. Please choose this whitelist_10x for 10x 3'v3
#whiteList="/singlecell_whitelist_Path/whitelist_10x 3'v3.txt"
#barcode_setting="--soloCBstart 1 --soloCBlen 16 --soloUMIstart 17 --soloUMIlen 12 --soloBarcodeReadLength 0"

## output config
soloFeatures="Gene Velocyto"
outSAMSettings="--outSAMtype BAM Unsorted --outSAMunmapped Within"

#Generate a standard BAM file
outSAMSettings="--outSAMtype None"

inFASTQ_cDNA_list=()
inFASTQ_barcode_list=()

# Loop through sample IDs
for sampleID in SRR123456789 SRR987654321; do  # just for e.g.
    inFASTQ_cDNA_list+=("$inPath/${sampleID}_2.fastq.gz")
    inFASTQ_barcode_list+=("$inPath/${sampleID}_1.fastq.gz")
done

inFASTQ_cDNA=$(IFS=", "; echo "${inFASTQ_cDNA_list[*]}")
inFASTQ_barcode=$(IFS=", "; echo "${inFASTQ_barcode_list[*]}")

echo "inFASTQ_cDNA=$inFASTQ_cDNA"
echo "inFASTQ_barcode=$inFASTQ_barcode"

outPrefix="$outPath/combinedSample"

mkdir -p $outPrefix

##==== cmds ====
# Here we passed all files as a single string, which STAR may not accept in this format!
STAR --genomeDir $refIndex \
--runThreadN $CPU \
$outSAMSettings \
--outFileNamePrefix $outPrefix/ \
--readFilesIn $inFASTQ_cDNA $inFASTQ_barcode \
--readFilesCommand zcat \
--soloType CB_UMI_Simple \
$barcode_setting \
--soloCBwhitelist $whiteList \
--soloCellFilter EmptyDrops_CR \
--soloFeatures $soloFeatures