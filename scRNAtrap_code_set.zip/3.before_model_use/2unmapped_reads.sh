# Navigate to the directory where the BAM file is located.
cd BAM_File_Path

# Filter out reads with a FLAG of 4.
samtools view -b -f 4 Aligned.out.bam > unmapped_reads.bam

# After the run completes, an unmapped_reads.bam file will appear in the original directory. 

# Warning: 
# The file size must be greater than 4 KB to meet the requirements.