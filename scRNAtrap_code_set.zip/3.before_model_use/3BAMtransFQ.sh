#!/bin/bash

BAM_FILE="BAM_file_Path"

OUTPUT_DIR="Output_BAM_fastq_Path"
mkdir -p ${OUTPUT_DIR}

OUTPUT_FASTQ="${OUTPUT_DIR}/file_name.fastq"

echo "Converting ${BAM_FILE} to ${OUTPUT_FASTQ}"
samtools fastq "${BAM_FILE}" > "${OUTPUT_FASTQ}"