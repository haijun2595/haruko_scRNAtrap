import os

def convert_fastq_to_fasta(input_file, output_file):
    #discard any reads containing "N"
    with open(input_file, 'r') as fq, open(output_file, 'w') as fa:
        while True:
            header = fq.readline().strip()
            if not header:
                break
            sequence = fq.readline().strip()
            plus = fq.readline().strip()
            quality = fq.readline().strip()
            if 'N' not in sequence:
                fa.write(f"{sequence}\n")

def main():
    input_dir = "Output_fastq2_intersection_Path"
    output_dir = "Output_fastq2_intersection_fasta_Path"

    os.makedirs(output_dir, exist_ok=True)

    for file_name in os.listdir(input_dir):
        if file_name.endswith(".fastq"):
            input_file = os.path.join(input_dir, file_name)
            output_file = os.path.join(output_dir, file_name.replace(".fastq", ".fasta"))
            convert_fastq_to_fasta(input_file, output_file)

    print("The conversion of FASTQ to FASTA files has been successfully completed.")

if __name__ == "__main__":
    main()