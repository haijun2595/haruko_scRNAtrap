#This step is performed by R on a Windows 10 system, not Linux.
#However, we move the analysis results to a Linux server for subsequent analysis.
rm(list=ls())
library(dplyr)
library(Seurat)
library(patchwork)
library(tidyverse)
library(magrittr)
library(ggsci)
library(pheatmap)
library(ggplot2)
setwd("D:/work_dir")
GSMexample.data <- Read10X(data.dir = "D:/dir_of_barcodes.tsv.gz; features.tsv.gz; matrix.mtx.gz")
GSMexample <- CreateSeuratObject(counts = GSMexample.data, project = "GSMexample", min.cells = 3, min.features = 200)
save(GSMexample, file = "GSMexample.Rdata")
load("GSMexample.Rdata")
scRNA<-GSMexample
table(scRNA$orig.ident)

scRNA[["percent.mt"]] <- PercentageFeatureSet(scRNA, pattern = "^MT-")
scRNA[["percent.rb"]] <- PercentageFeatureSet(scRNA, pattern = "^RB[SL]")
HB.genes <- c("HBA1","HBA2","HBB","HBD","HBE1","HBG1","HBG2","HBM","HBQ1","HBZ")
HB_m <- match(HB.genes, rownames(scRNA@assays$RNA))
HB.genes <- rownames(scRNA@assays$RNA)[HB_m]
HB.genes <- HB.genes[!is.na(HB.genes)]
scRNA[["percent.hb"]]<-PercentageFeatureSet(scRNA, features = HB.genes)

pdf(file = "fig1 before_qc.pdf",width = 12,height = 5)
VlnPlot(scRNA, features = c("nFeature_RNA", "nCount_RNA", "percent.mt","percent.rb"), ncol = 4,pt.size = 0)
dev.off()

pdf(file = "fig2_read_depth.pdf.pdf",width = 12,height = 8)
plot1 <- FeatureScatter(scRNA, feature1 = "nCount_RNA", feature2 = "percent.mt")
plot2 <- FeatureScatter(scRNA, feature1 = "nCount_RNA", feature2 = "nFeature_RNA")
plot3 <- FeatureScatter(scRNA, feature1 = "nCount_RNA", feature2 = "percent.hb")
CombinePlots(plots = list(plot1,plot2,plot3),nrow=1,legend = "none")
dev.off()

scRNA<- subset(scRNA, subset = nFeature_RNA > 500 & nFeature_RNA < 4500 & percent.mt < 10&
                 percent.hb<1&nCount_RNA<quantile(nCount_RNA,0.97)
               &nCount_RNA>1000)
scRNA <- NormalizeData(scRNA, normalization.method = "LogNormalize", scale.factor = 10000)

scRNA <- FindVariableFeatures(scRNA, selection.method = "vst", nfeatures = 2000)
top10<-head(VariableFeatures(scRNA),10)
plot1 <- VariableFeaturePlot(scRNA)
p2 <- LabelPoints(plot = plot1, points = top10, repel = TRUE)
p<-plot1 + plot2
ggsave("fig3 High variable gene.pdf", p2, width = 10, height = 6)
ggsave("afterQC3.pdf", p, width = 10, height = 6)

all.genes <- rownames(scRNA)
scRNA <- ScaleData(scRNA, features = all.genes)
save(scRNA,file = "scRNA_QC1.Rds")

mt.gene<-grep("^MT-",rownames(scRNA),value = T,ignore.case = T)
tmp <- RunPCA(scRNA, features = mt.gene,verbose = F)
p <- DimPlot(tmp,reduction ="pca",group.by = "orig.ident") 
ggsave("fig4 mito_pca.pdf", p, width = 10, height = 6)
rm(tmp)

rb.gene<-grep("^RB[SL]",rownames(scRNA),value = T,ignore.case = T)
tmp <- RunPCA(scRNA, features = rb.gene,verbose = F)
p <- DimPlot(tmp,reduction ="pca",group.by = "orig.ident") 
ggsave("fig5 rito_pca.pdf", p, width = 10, height = 6)
rm(tmp)

g2m_genes<-cc.genes$g2m.genes
g2m_genes<-CaseMatch(search = g2m_genes,match = rownames(scRNA))
s_genes<-cc.genes$s.genes
s_genes<-CaseMatch(search = s_genes,match = rownames(scRNA))
scRNA<-CellCycleScoring(scRNA,g2m.features = g2m_genes,s.features=s_genes)
tmp <- RunPCA(scRNA, features = c(g2m_genes,s_genes),verbose = F)
p <- DimPlot(tmp,reduction ="pca",group.by = "orig.ident") 
ggsave("fig6 CellCycle_pca.pdf", p, width = 10, height = 6)
meta<-scRNA@meta.data
View(meta)

scRNA = RunPCA(object = scRNA,npcs = 30, pc.genes = VariableFeatures(object = scRNA))
#scRNA <- RunPCA(scRNA, features = VariableFeatures(object = scRNA))

pdf(file = "fig7 PCA.pdf",width = 8,height = 6)
VizDimLoadings(object = scRNA, dims = 1:4, reduction = "pca",nfeatures = 15)
dev.off()

pdf(file = "fig8 PCA.pdf",width = 8,height = 6)
DimPlot(object = scRNA, reduction = "pca")
dev.off()
#print(OS.combined[["pca"]], dims = 1:5, nfeatures = 5)

pdf(file = "ElbowPlot.pdf")
ElbowPlot(scRNA)
dev.off()

scRNA <- scRNA %>%
  RunTSNE(dims = 1:10) %>% 
  FindNeighbors( dims = 1:10) %>% 
  RunUMAP(dims=1:10)
save(scRNA,file = "scRNA3.Rds")

test <- scRNA
test <- FindClusters(test, resolution = c(seq(0.1,1,0.1)))
View(test@meta.data)
library(clustree)
pdf(file ="tree.pdf", width =6, height =14)
clustree(test@meta.data, prefix = "RNA_snn_res.")
dev.off()

scRNA<-FindClusters(scRNA,resolution = 0.1)
table(scRNA$seurat_clusters)

pdf(file = "UMAP.pdf")  
DimPlot(scRNA, label = T)
dev.off()
pdf(file = "UMAP2.pdf")    
DimPlot(scRNA, group.by = "orig.ident")
dev.off()

pdf(file = "tSNE.pdf")
DimPlot(scRNA, label = T, reduction = "tsne")
dev.off()
pdf(file = "tSNE2.pdf")
DimPlot(scRNA, group.by = "orig.ident", reduction = "tsne")
dev.off()
save(scRNA,file = "scRNA4.Rdata")
load("scRNA4.Rdata")

markers <- FindAllMarkers(scRNA, only.pos = TRUE, min.pct = 0.25, logfc.threshold = 0.25)
write.csv(markers, file = "markers.csv")
meta<-scRNA@meta.data
write.csv(meta, file = "metadata.csv")

original_clusters <- levels(scRNA)

cell.type <- original_clusters

cell.type[which(original_clusters == "3")] <- "Tumor Cells"

names(cell.type) <- original_clusters
scRNA <- RenameIdents(scRNA, cell.type)

scRNA$celltype <- Idents(scRNA)

p1 <- DimPlot(scRNA, reduction = "umap", label = TRUE, label.size = 3.5, group.by = "celltype", raster = FALSE)

ggsave("umap_celltype.pdf", p1, width = 12, height = 8)