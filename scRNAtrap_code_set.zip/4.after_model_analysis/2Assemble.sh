#We initially planned to assemble reads during the design phase by Bash, 
#but ultimately abandoned this step.