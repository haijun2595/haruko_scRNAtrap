import os

def process_virus():
    base_dir = "After_model_fasta_file_Path"
    output_dir = "Output_small_fastq_Path"
    fastq_file = "Output_fastq2_intersection_Path/file_name.fastq"
    virus_fasta = os.path.join(base_dir, "virus.fasta")
    virus_fastq_output = os.path.join(output_dir, "virusFq.fastq")

    def read_fasta(fasta_file):
        with open(fasta_file, 'r') as f:
            return set(f.read().splitlines())

    def write_fastq(output_file, fastq_entries):
        with open(output_file, 'w') as f:
            for entry in fastq_entries:
                f.write("\n".join(entry) + "\n")

    def read_fastq(fastq_file):
        with open(fastq_file, 'r') as f:
            lines = f.read().splitlines()
            fastq_dict = {}
            for i in range(0, len(lines), 4):
                header = lines[i].strip()
                sequence = lines[i+1].strip()
                plus = lines[i+2].strip()
                quality = lines[i+3].strip()
                fastq_dict[sequence] = (header, sequence, plus, quality)
        return fastq_dict

    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    fasta_reads = read_fasta(virus_fasta)
    fastq_dict = read_fastq(fastq_file)
    matched_entries = []

    for read in fasta_reads:
        if read in fastq_dict:
            matched_entries.append(fastq_dict[read])

    write_fastq(virus_fastq_output, matched_entries)

def main():
    process_virus()

if __name__ == "__main__":
    main()