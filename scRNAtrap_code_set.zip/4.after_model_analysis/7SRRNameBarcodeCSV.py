import csv

results_csv_path = 'Refine_Output_file_Path/Refine_Virus_Name.csv'
barcode_csv_path = 'Output_SRR_barcode_file_Path/virus_SRR_barcode.csv'
output_csv_path = 'Output_SRR_Name_barcode_file_Path/SRR_Name_barcode_CSV.csv'

barcode_dict = {}
with open(barcode_csv_path, mode='r') as barcode_file:
    barcode_reader = csv.reader(barcode_file)
    header = next(barcode_reader)
    for row in barcode_reader:
        query_id = row[0]
        barcode = row[1]
        barcode_dict[query_id] = barcode

with open(results_csv_path, mode='r') as results_file:
    results_reader = csv.reader(results_file)
    results_header = next(results_reader)

    with open(output_csv_path, mode='w', newline='') as output_file:
        output_writer = csv.writer(output_file)
        
        output_header = results_header + ['Barcode']
        output_writer.writerow(output_header)
        
        for row in results_reader:
            query_id = row[0]
            barcode = barcode_dict.get(query_id, '')
            output_row = row + [barcode]
            output_writer.writerow(output_row)

print("Results are saved as", output_csv_path)