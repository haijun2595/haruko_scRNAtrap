#!/bin/bash

export PATH=/media/hmw/contigs/BLASTn/ncbi-blast-2.15.0+/bin:$PATH

FASTQ_FILE=Output_fastq2_intersection_Path/file_name.fastq
DB_NAME=Virus_db_Path
TEMP_DIR=Output_Path_Name/temp
OUTPUT_DIR=Output_Path_Name/virus
FASTA_FILE=$TEMP_DIR/file_name_temp.fasta
OUTPUT_TXT_FILE=$OUTPUT_DIR/file_name.txt

mkdir -p $OUTPUT_DIR
mkdir -p $TEMP_DIR

echo "Converting FASTQ to FASTA..."
awk 'NR%4==1{print ">"$0} NR%4==2{print $0}' $FASTQ_FILE > $FASTA_FILE

echo "Running BLAST..."
blastn -query $FASTA_FILE -db $DB_NAME -out $OUTPUT_TXT_FILE -evalue 0.01 -word_size 15 -outfmt 6

if [ $? -eq 0 ]; then
    echo "BLAST is success, output file is saved in $OUTPUT_TXT_FILE"
else
    echo "BLAST is fail."
fi

echo "Cleaning up..."
rm -rf $TEMP_DIR

echo "Finished"