import csv
from collections import defaultdict

input_file = 'Output_file_Path/Virus_Name.csv'
output_file = 'Refine_Output_file_Path/Refine_Virus_Name.csv'

query_dict = defaultdict(list)
with open(input_file, 'r') as infile:
    reader = csv.reader(infile)
    header = next(reader)
    query_id_index = header.index("Query ID")
    bit_score_index = header.index("Bit Score")

    for row in reader:
        query_id = row[query_id_index]
        try:
            bit_score = float(row[bit_score_index])
            query_dict[query_id].append((row, bit_score))
        except ValueError:
            print(f"Skipping row with invalid Bit Score: {row[bit_score_index]}")

filtered_rows = []
for query_id, rows in query_dict.items():
    max_bit_score = max(rows, key=lambda x: x[1])[1]
    for row, bit_score in rows:
        if bit_score == max_bit_score:
            filtered_rows.append(row)

with open(output_file, 'w', newline='') as outfile:
    writer = csv.writer(outfile)
    writer.writerow(header)
    writer.writerows(filtered_rows)

print(f"Refined results are saved as {output_file}")