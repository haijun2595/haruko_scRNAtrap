import csv
from Bio import SeqIO

input_fastq = "Output_file_Path/smallVirusFQ1.fastq"

output_csv = "Output_SRR_barcode_file_Path/virus_SRR_barcode.csv"

with open(output_csv, 'w', newline='') as csvfile:
    csv_writer = csv.writer(csvfile)
    csv_writer.writerow(['Query ID', 'Barcode'])

    for record in SeqIO.parse(input_fastq, "fastq"):
        srr_full = record.description
        srr = srr_full.split()[0]
        if not srr.startswith("@"):
            srr = "@" + srr
        barcode = str(record.seq)[:16]
        csv_writer.writerow([srr, barcode])

print("Results are saved as", output_csv)