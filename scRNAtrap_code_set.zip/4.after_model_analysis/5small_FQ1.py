import os

def read_fastq(file_path):
    with open(file_path, 'r') as file:
        while True:
            header = file.readline().strip()
            if not header:
                break
            sequence = file.readline().strip()
            plus = file.readline().strip()
            quality = file.readline().strip()
            yield header, sequence, plus, quality

def load_small_fastq(file_path):
    srr_set = set()
    for header, _, _, _ in read_fastq(file_path):
        srr_id = header.split(' ')[0]
        srr_set.add(srr_id)
    return srr_set

def filter_fastq_by_srr(fastq_files, srr_set, output_file):
    with open(output_file, 'w') as out_file:
        for fastq_file in fastq_files:
            for header, sequence, plus, quality in read_fastq(fastq_file):
                srr_id = header.split(' ')[0]
                if srr_id in srr_set:
                    out_file.write(f"{header}\n{sequence}\n{plus}\n{quality}\n")

small_fastq_path = 'Output_small_fastq_Path'
fastq_dir = 'Raw_fastq1_Path'
output_file = 'Output_file_Path/smallVirusFQ1.fastq'

srr_set = load_small_fastq(small_fastq_path)

# Gain all fastq1 file from fastq_dir
fastq_files = [os.path.join(fastq_dir, f) for f in os.listdir(fastq_dir) if f.endswith('_1.fastq')]

filter_fastq_by_srr(fastq_files, srr_set, output_file)

print("Finished")