import csv
import os

srr_file_path = 'Output_SRR_Name_barcode_file_Path/SRR_Name_barcode_CSV.csv'
metadata_file_path = 'scRNA_analysis_file_Path/metadata.csv'
output_file_path = 'Output_Final_Combine_file_Path/Final_Combine_Virus.csv'

with open(srr_file_path, mode='r', newline='') as srr_file:
    srr_reader = csv.reader(srr_file)
    srr_header = next(srr_reader)
    srr_data = [row for row in srr_reader]

with open(metadata_file_path, mode='r', newline='') as metadata_file:
    metadata_reader = csv.reader(metadata_file)
    metadata_header = next(metadata_reader)
    metadata_data = [row for row in metadata_reader]

metadata_dict = {row[0]: row[-2:] for row in metadata_data}

with open(output_file_path, mode='w', newline='') as output_file:
    writer = csv.writer(output_file)
    
    writer.writerow(srr_header + metadata_header[-2:])
    
    for row in srr_data:
        key = row[-1]
        if key in metadata_dict:
            new_row = row + metadata_dict[key]
        else:
            new_row = row + ["", ""]
        writer.writerow(new_row)

print("Combined results are saved as", output_file_path)