import csv

blast_results_file = 'Output_Path_Name/virus/file_name.txt'
virus_mapping_file = 'Virus_db_Path/virus_mapping_file.csv'
output_file = 'Output_file_Path/Virus_Name.csv'

virus_map = {}
with open(virus_mapping_file, mode='r') as infile:
    reader = csv.reader(infile)
    next(reader)  # skip head
    for rows in reader:
        subject_id, virus_name = rows
        virus_map[subject_id] = virus_name

def remove_version(accession):
    return accession.split('.')[0]

with open(blast_results_file, mode='r') as infile, open(output_file, mode='w', newline='') as outfile:
    reader = csv.reader(infile, delimiter='\t')
    writer = csv.writer(outfile)
    
    writer.writerow(['Query ID', 'Subject ID', '% Identity', 'Alignment Length', 'Mismatches', 
                     'Gap Openings', 'Query Start', 'Query End', 'Subject Start', 'Subject End', 
                     'E-value', 'Bit Score', 'Virus Name'])

    for rows in reader:
        query_id = rows[0]
        subject_id = rows[1]
        clean_subject_id = remove_version(subject_id)  # ȥ���汾��
        virus_name = virus_map.get(clean_subject_id, 'Unknown')
        writer.writerow(rows + [virus_name])

print(f"BLAST results are saved as {output_file}")