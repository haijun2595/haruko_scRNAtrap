import os
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from Bio import SeqIO
import torch.nn.functional as F
from sklearn.metrics import accuracy_score, recall_score, precision_score, f1_score, roc_auc_score, confusion_matrix
import matplotlib.pyplot as plt
import pickle
mask = False
#mask = True


def plot_metrics(metrics, num_epochs, filename):
    epochs = range(1, num_epochs + 1)
    plt.figure(figsize=(12, 6))

    for metric_name, metric_values in metrics.items():
        plt.plot(epochs, metric_values, label=metric_name)

    plt.xlabel("Epoch")
    plt.ylabel("Metric Value")
    plt.legend()

    # Save the figure
    plt.savefig(filename)

    plt.show()

def sequence_to_array(seq, mapping):
    return np.array([mapping[s] for s in seq])

def load_data():
    data = []
    labels = []
    unique_chars = set()
    if mask:
        #classes = ['bacteria10Masked', 'human10Masked', 'virus10Masked']
        #for label, file in enumerate(classes):
        #    with open(os.path.join('Path', file + '.fasta'), 'r') as handle:
        #        for record in handle.readlines():
        #            seq = record.upper().strip()
        #           length = len(seq)
        #           unique_chars.update(seq)
        #           data.append(seq)
        #           labels.append(label)
        #label_encoder = LabelEncoder()
        #numeric_labels = label_encoder.fit_transform(labels)
    else:
        classes = ['bacteria48bp5M', 'human48bp5M', 'virus48bp5M']
        for label, file in enumerate(classes):
            with open(os.path.join('5million_fasta_OutputPath_48bp', file + '.fasta'), 'r') as handle:
                for record in handle.readlines():
                    seq = record.upper().strip()
                    length = len(seq)
                    unique_chars.update(seq)
                    data.append(seq)
                    labels.append(label)
        label_encoder = LabelEncoder()
        numeric_labels = label_encoder.fit_transform(labels)

    # classes = ['bacteria', 'human', 'virus']
    # for label, file in enumerate(classes):
    #     with open(os.path.join('forTest', file + '.fasta'), 'r') as handle:
    #         for record in handle.readlines():
    #             seq = record.upper().strip()
    #             unique_chars.update(seq)
    #             data.append(seq)
    #             labels.append(label)
    # label_encoder = LabelEncoder()
    # numeric_labels = label_encoder.fit_transform(labels)
    return data, numeric_labels, unique_chars, length

class DNADataset(Dataset):
    def __init__(self, data, labels):
        self.data = data
        self.labels = labels

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        return torch.from_numpy(self.data[idx]).long(), self.labels[idx]

class DNA1DCNN(nn.Module):
    def __init__(self, length, unique_chars, num_classes):
        super(DNA1DCNN, self).__init__()
        num_input_channels = len(unique_chars)
        self.lstm = nn.LSTM(1, 16, batch_first=True)
        self.dropout1 = nn.Dropout(0.1)
        self.conv1 = nn.Conv1d(length, 64, kernel_size=3, stride=1, padding=1)
        self.conv2 = nn.Conv1d(64, 32, kernel_size=3, stride=1, padding=1)
        self.conv3 = nn.Conv1d(32, 16, kernel_size=3, stride=1, padding=1)
        self.relu1 = nn.ReLU()
        self.fc1 = nn.Linear(16, 1)
        self.fc2 = nn.Linear(16, num_classes)

    def forward(self, x):
        x, _ = self.lstm(x)
        x = self.dropout1(x)
        x = self.conv1(x)
        x = self.conv2(x)
        x = self.conv3(x)
        x = self.relu1(x)
        x = self.fc1(x)
        x = x.view(x.size(0), -1)
        x = self.fc2(x)
        return x
def main():
    # Load data
    data, labels, unique_chars, length = load_data()
    char_mapping = {char: i for i, char in enumerate(unique_chars)}
    # Save char_mapping with pickle
    with open('char_mapping.pkl', 'wb') as f:
        pickle.dump(char_mapping, f)

    print(unique_chars)
    # Convert sequences to arrays using the char_mapping
    data = np.array([sequence_to_array(seq, char_mapping) for seq in data])
    print(f"Loaded {len(data)} sequences and {len(labels)} labels .")
    # Split data into train and test sets
    X_train, X_test, y_train, y_test = train_test_split(data, labels, test_size=0.2, random_state=42)

    # Create PyTorch datasets and dataloaders
    train_dataset = DNADataset(X_train, y_train)
    test_dataset = DNADataset(X_test, y_test)
    train_loader = DataLoader(train_dataset, batch_size=100, shuffle=True)
    test_loader = DataLoader(test_dataset, batch_size=100, shuffle=False)

    # Create model, loss function and optimizer
    model = DNA1DCNN(length, unique_chars, num_classes=3)
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=0.001)

    # Train model
    num_epochs = 30
    best_val_acc = 0.0
    best_model_path = "best_model.pth"
    metrics = {
        "AUROC": [],
        "Accuracy": [],
        "Recall": [],
        "Precision": [],
        "F1": []
    }

    for epoch in range(num_epochs):
        model.train()
        epoch_loss = 0
        correct = 0
        total = 0
        for batch in train_loader:
            inputs, targets = batch
            inputs = inputs.float()
            inputs = inputs.unsqueeze(1)
            inputs = inputs.permute(0, 2, 1)

            optimizer.zero_grad()
            outputs = model(inputs)
            loss = criterion(outputs, targets)
            loss.backward()
            optimizer.step()

            epoch_loss += loss.item()
            _, predicted = torch.max(outputs.data, 1)
            total += targets.size(0)
            correct += (predicted == targets).sum().item()

        epoch_loss /= len(train_loader)
        train_acc = 100 * correct / total
        # Test model
        model.eval()
        correct = 0
        total = 0

        # Calculate metrics
        y_true = np.array(y_test)
        y_pred = np.zeros_like(y_true)
        y_score = np.zeros((len(y_true), 3))
        index=0
        with torch.no_grad():
            for batch in test_loader:
                inputs, targets = batch
                inputs = inputs.float()
                inputs = inputs.unsqueeze(1)
                inputs = inputs.permute(0, 2, 1)

                outputs = model(inputs)
                _, predicted = torch.max(outputs.data, 1)

                y_score_batch = F.softmax(outputs, dim=1).numpy()
                y_pred_batch = predicted.numpy()

                batch_size = len(targets)
                y_pred[index:index + batch_size] = y_pred_batch
                y_score[index:index + batch_size] = y_score_batch

                index += batch_size

                total += targets.size(0)
                correct += (predicted == targets).sum().item()

        val_acc = 100 * correct / total
        # Check if this is the best model so far
        if val_acc > best_val_acc:
            best_val_acc = val_acc
            torch.save(model.state_dict(), best_model_path)

        auroc = roc_auc_score(y_true, y_score, multi_class="ovr")
        acc = accuracy_score(y_true, y_pred)
        recall = recall_score(y_true, y_pred, average="macro")
        precision = precision_score(y_true, y_pred, average="macro")
        f1 = f1_score(y_true, y_pred, average="macro")

        # Store metrics
        metrics["AUROC"].append(auroc)
        metrics["Accuracy"].append(acc)
        metrics["Recall"].append(recall)
        metrics["Precision"].append(precision)
        metrics["F1"].append(f1)

        print(
            f"Epoch {epoch + 1}/{num_epochs}, Loss: {epoch_loss:.4f}, Train Acc: {train_acc:.2f}%, Val Acc: {val_acc:.2f}%, "
            f"AUROC: {auroc:.4f}, Recall: {recall:.4f}, Precision: {precision:.4f}, F1: {f1:.4f}"
        )


    print(f"Best validation accuracy: {best_val_acc:.2f}%")
    plot_metrics(metrics, num_epochs, "metrics.png")

if __name__ == "__main__":
    main()