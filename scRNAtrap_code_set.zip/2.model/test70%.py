import os
import pickle

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from main48bp15M import DNA1DCNN, DNADataset
from scipy.stats import mode
from sklearn.metrics import roc_auc_score, accuracy_score, recall_score, precision_score, f1_score
from sklearn.preprocessing import OneHotEncoder

length=48

def sequence_to_array(seq, mapping):
    return np.array([mapping[s] for s in seq])

def sliding_window(seq, window_size=48, step=1):
    return [seq[i:i + window_size] for i in range(0, len(seq) - window_size + 1, step)]


def load_data():
    data = []
    labels = []
    unique_chars = set()
    classes = ['bacteria', 'human', 'virus']
    for label, file in enumerate(classes):
        with open(os.path.join('forTest_Path', file + '.fasta'), 'r') as handle:
            for record in handle.readlines():
                seq = record.upper().strip()
                length = len(seq)
                unique_chars.update(seq)
                data.append(seq)
                labels.append(label)
    label_encoder = LabelEncoder()
    numeric_labels = label_encoder.fit_transform(labels)

    return data, numeric_labels, unique_chars, length

def test_model(test_dataset, model_path):
    # Load the trained model
    model = DNA1DCNN(length, loaded_char_mapping, num_classes=3)
    model.load_state_dict(torch.load(model_path))

    # Switch the model to evaluation mode
    model.eval()

    correct = 0
    total = len(test_dataset)
    y_true = []
    y_pred = []
    drop = 0

    with torch.no_grad():
        for i in range(total):
            input, target = test_dataset[i]

            # Apply sliding window to the input
            input_window = sliding_window(input.numpy(), window_size=length)
            input = torch.tensor(input_window).long()
            input = input.float()
            input = input.unsqueeze(1)
            input = input.permute(0, 2, 1)

            outputs = model(input)
            _, predicted = torch.max(outputs.data, 1)

            final_prediction = mode(predicted.numpy()).mode[0]

            unique, counts = np.unique(predicted, return_counts=True)
            percentages = counts / len(predicted)

            # if percentages < 70% discard
            if percentages[np.argmax(counts)] < 0.7:
                drop += 1
                continue

            if final_prediction == target:
                correct += 1

            y_true.append(target)
            y_pred.append(final_prediction)

    # Convert y_pred to one-hot encoding
    one_hot_encoder = OneHotEncoder(sparse=False, categories=[range(3)])  # Specify all possible categories
    y_pred_one_hot = one_hot_encoder.fit_transform(np.array(y_pred).reshape(-1, 1))

    # Calculate metrics
    auroc = roc_auc_score(y_true, y_pred_one_hot, multi_class="ovr", average="macro")
    accuracy = accuracy_score(y_true, y_pred)
    recall = recall_score(y_true, y_pred, average="macro")
    precision = precision_score(y_true, y_pred, average="macro")
    f1 = f1_score(y_true, y_pred, average="macro")
    drop_ratio = drop / total
    print(f"AUROC: {auroc:.2f}")
    print(f"Accuracy: {accuracy:.2f}")
    print(f"Recall: {recall:.2f}")
    print(f"Precision: {precision:.2f}")
    print(f"F1: {f1:.2f}")
    print(f"dropout%: {drop_ratio:.2f}")

# Call the test function
if __name__ == "__main__":
    data, labels, _, _ = load_data()  # Call load_data to set the global variables
    with open('char_mapping.pkl', 'rb') as f:
        loaded_char_mapping = pickle.load(f)
    data = np.array([sequence_to_array(seq, loaded_char_mapping) for seq in data])
    test_dataset = DNADataset(data, labels)
    test_model(test_dataset, 'best_model.pth')