import os
import pickle

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from main48bp15M import DNA1DCNN, DNADataset
from scipy.stats import mode

length = 48

category_mapping = {0: 'bacteria.txt', 1: 'human.txt', 2: 'virus.txt'}

output_files = {category: open(category_mapping[category], 'a') for category in category_mapping}


def sequence_to_array(seq, mapping):
    return np.array([mapping[s] for s in seq])

def sliding_window(seq, window_size=48, step=1):
    return [seq[i:i + window_size] for i in range(0, len(seq) - window_size + 1, step)]


def load_data():
    data = []
    unique_chars = set()
    with open("Output_fastq2_intersection_fasta_Path/file_name.fasta", 'r') as handle: #��Ϊ����ļ�·��
            for record in handle.readlines():
                seq = record.upper().strip()
                length = len(seq)
                unique_chars.update(seq)
                data.append(seq)

    return data, unique_chars, length

data, unique_chars, _ = load_data()

model = DNA1DCNN(length, {}, num_classes=3)
model.load_state_dict(torch.load("best_model.pth"))
with open('char_mapping.pkl', 'rb') as f:
    loaded_char_mapping = pickle.load(f)
for seq in data:
    input = np.array(sequence_to_array(seq, loaded_char_mapping))
    input_window = sliding_window(input, window_size=length)
    inputs = torch.tensor(input_window).long()
    inputs = inputs.float()
    inputs = inputs.unsqueeze(1)
    inputs = inputs.permute(0, 2, 1)




    outputs = model(inputs)
    _, predicted = torch.max(outputs.data, 1)
    final_prediction = mode(predicted).mode

    unique, counts = np.unique(predicted, return_counts=True)
    percentages = counts / len(predicted)

    if percentages[np.argmax(counts)] > 0.7:
        output_files[final_prediction].write(seq + '\n')
print("Finished")